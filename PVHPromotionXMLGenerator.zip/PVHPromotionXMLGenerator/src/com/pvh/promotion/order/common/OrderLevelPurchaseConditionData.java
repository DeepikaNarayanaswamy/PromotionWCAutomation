package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OrderLevelPurchaseConditionData {
	
	@XmlElement(name = "Language")
	private String language;
	
	@XmlElement(name = "Currency")
	private String currency;

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
