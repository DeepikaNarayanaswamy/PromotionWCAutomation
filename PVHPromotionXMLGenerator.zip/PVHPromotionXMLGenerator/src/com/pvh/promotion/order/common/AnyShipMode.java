package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AnyShipMode {

	@XmlElement(name = "SubType")
	private String subType;
	
	@XmlElement(name = "Sequence")
	private double sequence;

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}


	
}
