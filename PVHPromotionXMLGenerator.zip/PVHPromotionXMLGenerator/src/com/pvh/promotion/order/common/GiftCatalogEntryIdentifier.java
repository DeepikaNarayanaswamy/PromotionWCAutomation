package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GiftCatalogEntryIdentifier {

	@XmlElement(name = "SubType")
	private String subType;
	
	@XmlElement(name = "Sequence")
	private double sequence;
	
	@XmlElement(name = "Data")
	private GiftCatalogEntryIdentifierData giftCatalogEntryIdentifierData;

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}

	public void setGiftCatalogEntryIdentifierData(GiftCatalogEntryIdentifierData giftCatalogEntryIdentifierData) {
		this.giftCatalogEntryIdentifierData = giftCatalogEntryIdentifierData;
	}

}
