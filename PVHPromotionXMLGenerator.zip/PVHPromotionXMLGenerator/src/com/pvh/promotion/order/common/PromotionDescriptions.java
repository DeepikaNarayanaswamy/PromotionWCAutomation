package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PromotionDescriptions {
	
	@XmlElement(name = "Description")
	private PromotionDescription promotionDescription;

	public void setPromotionDescription(PromotionDescription promotionDescription) {
		this.promotionDescription = promotionDescription;
	}
}
