package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GiftCatalogEntryIdentifierData {

	@XmlElement(name = "Identifier")
	private String identifier;
	
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
}
