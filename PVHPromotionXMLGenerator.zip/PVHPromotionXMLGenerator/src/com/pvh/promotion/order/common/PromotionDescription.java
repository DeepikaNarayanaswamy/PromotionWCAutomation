package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PromotionDescription {

	@XmlElement(name = "LanguageId")
	private int languageId;
	
	@XmlElement(name = "ShortDescription")
	private String shortDescription;
	
	@XmlElement(name = "LongDescription")
	private String longDescription;

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	
	
	
}
