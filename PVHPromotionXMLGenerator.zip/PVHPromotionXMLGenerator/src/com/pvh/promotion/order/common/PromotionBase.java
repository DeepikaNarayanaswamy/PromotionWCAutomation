package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PromotionBase {
	
	@XmlElement(name = "AdministrativeName")
	private String administrativeName;

	@XmlElement(name = "PromotionGroupIdentifier")
	private String promotionGroupIdentifier;
	
	@XmlElement(name = "Comments")
	private String comments;
	
	@XmlElement(name = "Priority")
	private int priority;
	
	@XmlElement(name = "Exclusive")
	private int exclusive;
	
	@XmlElement(name = "LastUpdateByLogonId")
	private String lastUpdateByLogonId;
	
	@XmlElement(name = "PerOrderLimit")
	private int perOrderLimit;
	
	@XmlElement(name = "PerShopperLimit")
	private int perShopperLimit;
	
	@XmlElement(name = "ApplicationLimit")
	private int applicationLimit;
	
	@XmlElement(name = "TargetSales")
	private double targetSales;
	
	@XmlElement(name = "PromotionTypeName")
	private String promotionTypeName;
	
	@XmlElement(name = "ControlParameter")
	private String controlParameter;
	
	@XmlElement(name = "StartDate")
	private String startDate;
	
	@XmlElement(name = "EndDate")
	private String endDate;
	
	@XmlElement(name = "DailyStartTime")
	private String dailyStartTime;
	
	@XmlElement(name = "DailyEndTime")
	private String dailyEndTime;
	
	@XmlElement(name = "Sunday")
	private int sunday;
	
	@XmlElement(name = "Monday")
	private int monday;
	
	@XmlElement(name = "Tuesday")
	private int tuesday;
	
	@XmlElement(name = "Wednesday")
	private int wednesday;
	
	@XmlElement(name = "Thursday")
	private int thursday;
	
	@XmlElement(name = "Friday")
	private int friday;
	
	@XmlElement(name = "Saturday")
	private int saturday;
	
	@XmlElement(name = "Type")
	private int type;
	
	@XmlElement(name = "EffectiveDays")
	private int effectiveDays;
	
	@XmlElement(name = "ExpirationDays")
	private int expirationDays;
	
	@XmlElement(name = "AllowTransfer")
	private int allowTransfer;
	
	@XmlElement(name = "PromotionCodeRequired")
	private int promotionCodeRequired;
	
	@XmlElement(name = "DisplayLevel")
	private int displayLevel;

	public void setAdministrativeName(String administrativeName) {
		this.administrativeName = administrativeName;
	}

	public void setPromotionGroupIdentifier(String promotionGroupIdentifier) {
		this.promotionGroupIdentifier = promotionGroupIdentifier;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public void setExclusive(int exclusive) {
		this.exclusive = exclusive;
	}

	public void setLastUpdateByLogonId(String lastUpdateByLogonId) {
		this.lastUpdateByLogonId = lastUpdateByLogonId;
	}

	public void setPerOrderLimit(int perOrderLimit) {
		this.perOrderLimit = perOrderLimit;
	}

	public void setPerShopperLimit(int perShopperLimit) {
		this.perShopperLimit = perShopperLimit;
	}

	public void setApplicationLimit(int applicationLimit) {
		this.applicationLimit = applicationLimit;
	}

	public void setTargetSales(double targetSales) {
		this.targetSales = targetSales;
	}

	public void setPromotionTypeName(String promotionTypeName) {
		this.promotionTypeName = promotionTypeName;
	}

	public void setControlParameter(String controlParameter) {
		this.controlParameter = controlParameter;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setDailyStartTime(String dailyStartTime) {
		this.dailyStartTime = dailyStartTime;
	}

	public void setDailyEndTime(String dailyEndTime) {
		this.dailyEndTime = dailyEndTime;
	}

	public void setSunday(int sunday) {
		this.sunday = sunday;
	}

	public void setMonday(int monday) {
		this.monday = monday;
	}

	public void setTuesday(int tuesday) {
		this.tuesday = tuesday;
	}

	public void setWednesday(int wednesday) {
		this.wednesday = wednesday;
	}

	public void setThursday(int thursday) {
		this.thursday = thursday;
	}

	public void setFriday(int friday) {
		this.friday = friday;
	}

	public void setSaturday(int saturday) {
		this.saturday = saturday;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setEffectiveDays(int effectiveDays) {
		this.effectiveDays = effectiveDays;
	}

	public void setExpirationDays(int expirationDays) {
		this.expirationDays = expirationDays;
	}

	public void setAllowTransfer(int allowTransfer) {
		this.allowTransfer = allowTransfer;
	}

	public void setPromotionCodeRequired(int promotionCodeRequired) {
		this.promotionCodeRequired = promotionCodeRequired;
	}

	public void setDisplayLevel(int displayLevel) {
		this.displayLevel = displayLevel;
	}

	

}
