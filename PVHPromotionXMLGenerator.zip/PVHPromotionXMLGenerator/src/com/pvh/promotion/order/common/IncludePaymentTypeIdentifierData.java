package com.pvh.promotion.order.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class IncludePaymentTypeIdentifierData {

	@XmlElement(name = "PaymentType")
	private String paymentType;
	
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	
}
