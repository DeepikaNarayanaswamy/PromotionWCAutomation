package com.pvh.promotion.order.amountoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AmountOffDiscountRange {

	@XmlElement(name = "SubType")
	private String subType;
	
	@XmlElement(name = "Sequence")
	private double sequence;
	
	@XmlElement(name = "Data")
	private AmountOffDiscountRangeData amountOffDiscountRangeData ;

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}

	public void setAmountOffDiscountRangeData(AmountOffDiscountRangeData amountOffDiscountRangeData) {
		this.amountOffDiscountRangeData = amountOffDiscountRangeData;
	}

	
}
