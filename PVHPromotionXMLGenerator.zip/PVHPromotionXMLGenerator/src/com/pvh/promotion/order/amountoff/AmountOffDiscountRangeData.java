package com.pvh.promotion.order.amountoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AmountOffDiscountRangeData {

	@XmlElement(name = "AmountOff")
	private String amountOff;
	
	@XmlElement(name = "LowerBound")
	private String lowerBound;

	public void setAmountOff(String amountOff) {
		this.amountOff = amountOff;
	}

	public void setLowerBound(String lowerBound) {
		this.lowerBound = lowerBound;
	}
}
