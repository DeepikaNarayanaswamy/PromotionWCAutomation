package com.pvh.promotion.order.amountoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.TargetingCondition;

@XmlRootElement
public class AmountOffElements {

	@XmlElement(name = "TargetingCondition")
	private TargetingCondition targetingCondition;
	
	@XmlElement(name = "PurchaseCondition")
	private AmountOffPurchaseCondition amountOffPurchaseCondition;

	public void setTargetingCondition(TargetingCondition targetingCondition) {
		this.targetingCondition = targetingCondition;
	}

	public void setAmountOffPurchaseCondition(AmountOffPurchaseCondition amountOffPurchaseCondition) {
		this.amountOffPurchaseCondition = amountOffPurchaseCondition;
	}

}
