package com.pvh.promotion.order.amountoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Promotions")
public class AmountOffPromotions {
	
	@XmlElement(name = "PromotionData")
	private AmountOffPromotionData amountOffPromotionData;
	
	public void setAmountOffPromotionData(AmountOffPromotionData amountOffPromotionData) {
		this.amountOffPromotionData = amountOffPromotionData;
	}

}
