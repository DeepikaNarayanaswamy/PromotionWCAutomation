package com.pvh.promotion.order.freegift;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FreeGiftPurchaseConditionData {

	@XmlElement(name = "chooseBehavior")
	private String chooseBehavior;
	
	@XmlElement(name = "Language")
	private String language;
	
	@XmlElement(name = "Currency")
	private String currency;
	
	@XmlElement(name = "NoOfItems")
	private String noOfItems;
	
	@XmlElement(name = "MinimumPurchase")
	private String minimumPurchase;

	public void setChooseBehavior(String chooseBehavior) {
		this.chooseBehavior = chooseBehavior;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public void setNoOfItems(String noOfItems) {
		this.noOfItems = noOfItems;
	}

	public void setMinimumPurchase(String minimumPurchase) {
		this.minimumPurchase = minimumPurchase;
	}

}
