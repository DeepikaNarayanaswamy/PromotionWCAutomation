package com.pvh.promotion.order.freegift;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.TargetingCondition;

@XmlRootElement
public class FreeGiftElements {

	@XmlElement(name = "TargetingCondition")
	private TargetingCondition targetingCondition;
	
	@XmlElement(name = "PurchaseCondition")
	private FreeGiftPurchaseCondition freeGiftPurchaseCondition;

	public void setTargetingCondition(TargetingCondition targetingCondition) {
		this.targetingCondition = targetingCondition;
	}

	public void setFreeGiftPurchaseCondition(FreeGiftPurchaseCondition freeGiftPurchaseCondition) {
		this.freeGiftPurchaseCondition = freeGiftPurchaseCondition;
	}

}
