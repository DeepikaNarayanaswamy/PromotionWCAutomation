package com.pvh.promotion.order.freegift;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.pvh.promotion.order.common.AnyShipMode;
import com.pvh.promotion.order.common.GiftCatalogEntryIdentifier;
import com.pvh.promotion.order.common.GiftCatalogEntryIdentifierData;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifier;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifierData;
import com.pvh.promotion.order.common.PromotionBase;
import com.pvh.promotion.order.common.PromotionDescription;
import com.pvh.promotion.order.common.PromotionDescriptions;
import com.pvh.promotion.order.common.TargetingCondition;

public class FreeGiftXMLGenerator {

	public static void main(String[] args) {
		
	try
        {
			String suffix = Integer.toString((int) Math.floor(Math.random()*100));
			
			FreeGiftPromotions freeGiftPromotions = new FreeGiftPromotions();
			
			FreeGiftPromotionData promotionData = new FreeGiftPromotionData();

			PromotionBase base = new PromotionBase();
			base.setAdministrativeName(("Free_Gift_Order_").concat(suffix));
			base.setAllowTransfer(0);
			base.setApplicationLimit(-1);
			base.setComments("Free gift comments");
			base.setControlParameter("CMC");
			base.setDailyEndTime("2000-01-01 23:59:59.999");
			base.setDailyStartTime("2000-01-01 00:00:00.001");
			base.setDisplayLevel(1);
			base.setEffectiveDays(0);
			base.setEndDate("9999-12-31 23:59:59.999");
			base.setExclusive(4);
			base.setExpirationDays(0);
			base.setFriday(1);
			base.setLastUpdateByLogonId("wcsadmin");
			base.setMonday(1);
			base.setPerOrderLimit(-1);
			base.setPerShopperLimit(-1);
			base.setPriority(100);
			base.setPromotionCodeRequired(0);
			base.setPromotionGroupIdentifier("OrderLevelPromotion");
			base.setPromotionTypeName("OrderLevelFreeGift");
			base.setSaturday(1);
			base.setStartDate(new Timestamp(new Date().getTime()).toString());
			base.setSunday(1);
			base.setTargetSales(0.00000);
			base.setThursday(1);
			base.setTuesday(1);
			base.setType(0);
			base.setWednesday(1);
			
			promotionData.setPromotionBase(base);
			
			PromotionDescription description = new PromotionDescription();
			description.setLanguageId(-1);
			description.setLongDescription("Long free gift");
			description.setShortDescription("Short free gift");
			
			PromotionDescriptions descriptions = new  PromotionDescriptions();
			descriptions.setPromotionDescription(description);

			promotionData.setPromotionDescriptions(descriptions);
			
			FreeGiftElements elements = new FreeGiftElements();
			
			TargetingCondition targetingCondition = new TargetingCondition();
			
			targetingCondition.setSequence(0.0);
			targetingCondition.setSubType("TargetingCondition");
			
			elements.setTargetingCondition(targetingCondition);
			
			FreeGiftPurchaseCondition purchaseCondition = new FreeGiftPurchaseCondition();
			
			AnyShipMode anyShipMode = new AnyShipMode();
			anyShipMode.setSequence(0.0);
			anyShipMode.setSubType("Identifier_ShipMode");
			
			purchaseCondition.setAnyShipMode(anyShipMode);
			
			FreeGiftPurchaseConditionData freeGiftPurchaseConditionData = new FreeGiftPurchaseConditionData();
			freeGiftPurchaseConditionData.setChooseBehavior("addToCart");
			freeGiftPurchaseConditionData.setCurrency("USD");
			freeGiftPurchaseConditionData.setLanguage("-1");
			freeGiftPurchaseConditionData.setMinimumPurchase("1");
			freeGiftPurchaseConditionData.setNoOfItems("1");
			
			purchaseCondition.setFreeGiftPurchaseConditionData(freeGiftPurchaseConditionData);
			
			GiftCatalogEntryIdentifier giftCatalogEntryIdentifier = new GiftCatalogEntryIdentifier();
			
			GiftCatalogEntryIdentifierData giftCatalogEntryIdentifierData = new GiftCatalogEntryIdentifierData();
			giftCatalogEntryIdentifierData.setIdentifier("00631620615444");
			
			giftCatalogEntryIdentifier.setGiftCatalogEntryIdentifierData(giftCatalogEntryIdentifierData);
			giftCatalogEntryIdentifier.setSequence(0.0);
			giftCatalogEntryIdentifier.setSubType("Identifier_InheritedGiftCatalogEntry");
			
			purchaseCondition.setGiftCatalogEntryIdentifier(giftCatalogEntryIdentifier);
			
			IncludePaymentTypeIdentifier includePaymentTypeIdentifier = new IncludePaymentTypeIdentifier();
			
			IncludePaymentTypeIdentifierData includePaymentTypeIdentifierData = new IncludePaymentTypeIdentifierData();
			includePaymentTypeIdentifierData.setPaymentType("Any");
			
			includePaymentTypeIdentifier.setIncludePaymentTypeIdentifierData(includePaymentTypeIdentifierData);
			includePaymentTypeIdentifier.setSequence(0.0);
			includePaymentTypeIdentifier.setSubType("IncludePaymentTypeIdentifier");
			
			purchaseCondition.setIncludePaymentTypeIdentifier(includePaymentTypeIdentifier);
		
			purchaseCondition.setSequence(0.0);
			purchaseCondition.setSubtype("OrderLevelFreeGiftPurchaseCondition");
			
			elements.setFreeGiftPurchaseCondition(purchaseCondition);

			promotionData.setFreeGiftElements(elements);
			
			freeGiftPromotions.setFreeGiftPromotionData(promotionData);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(FreeGiftPromotions.class);
             
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
 
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
 
            StringWriter stringWriter = new StringWriter();
             
            jaxbMarshaller.marshal(freeGiftPromotions, stringWriter);
             
            String xmlContent = stringWriter.toString();
            System.out.println( xmlContent );
 
            try {
            	String path = "C:/IBM/WCDE80/samples/DataLoad/Promotion/FreeGift.xml";
                File newTextFile = new File(path);

                FileWriter fw = new FileWriter(newTextFile);
                fw.write(xmlContent);
                fw.close();

            } catch (IOException iox) {
                iox.printStackTrace();
            }
            
        } catch (JAXBException e) {
            e.printStackTrace();
        }
	}
}
