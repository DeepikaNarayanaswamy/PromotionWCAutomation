package com.pvh.promotion.order.freegift;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.AnyShipMode;
import com.pvh.promotion.order.common.GiftCatalogEntryIdentifier;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifier;

@XmlRootElement
public class FreeGiftPurchaseCondition {
	
	@XmlElement(name = "SubType")
	private String subtype;
	
	@XmlElement(name = "Sequence")
	private double sequence;
	
	@XmlElement(name = "Data")
	private FreeGiftPurchaseConditionData freeGiftPurchaseConditionData;
	
	@XmlElement(name = "IncludePaymentTypeIdentifier")
	private IncludePaymentTypeIdentifier includePaymentTypeIdentifier;

	@XmlElement(name = "AnyShipMode")
	private AnyShipMode anyShipMode;
	
	@XmlElement(name = "GiftCatalogEntryIdentifier")
	private GiftCatalogEntryIdentifier giftCatalogEntryIdentifier;

	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}

	public void setFreeGiftPurchaseConditionData(FreeGiftPurchaseConditionData freeGiftPurchaseConditionData) {
		this.freeGiftPurchaseConditionData = freeGiftPurchaseConditionData;
	}

	public void setIncludePaymentTypeIdentifier(IncludePaymentTypeIdentifier includePaymentTypeIdentifier) {
		this.includePaymentTypeIdentifier = includePaymentTypeIdentifier;
	}

	public void setAnyShipMode(AnyShipMode anyShipMode) {
		this.anyShipMode = anyShipMode;
	}

	public void setGiftCatalogEntryIdentifier(GiftCatalogEntryIdentifier giftCatalogEntryIdentifier) {
		this.giftCatalogEntryIdentifier = giftCatalogEntryIdentifier;
	}
}
