package com.pvh.promotion.order.freegift;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Promotions")
public class FreeGiftPromotions {
	
	@XmlElement(name="PromotionData")
	private FreeGiftPromotionData freeGiftPromotionData;

	public void setFreeGiftPromotionData(FreeGiftPromotionData freeGiftPromotionData) {
		this.freeGiftPromotionData = freeGiftPromotionData;
	}	
}
