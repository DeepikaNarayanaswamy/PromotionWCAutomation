package com.pvh.promotion.order.freegift;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.PromotionBase;
import com.pvh.promotion.order.common.PromotionDescriptions;

@XmlRootElement(name="PromotionData")
public class FreeGiftPromotionData {

	@XmlElement(name = "Base")
	private PromotionBase promotionBase;
	
	@XmlElement(name = "Descriptions")
	private PromotionDescriptions promotionDescriptions;
	
	@XmlElement(name = "Elements")
	private FreeGiftElements freeGiftElements;

	public void setPromotionBase(PromotionBase promotionBase) {
		this.promotionBase = promotionBase;
	}

	public void setPromotionDescriptions(PromotionDescriptions promotionDescriptions) {
		this.promotionDescriptions = promotionDescriptions;
	}

	public void setFreeGiftElements(FreeGiftElements freeGiftElements) {
		this.freeGiftElements = freeGiftElements;
	}

	
}
