package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Promotions")
public class PercentOffPromotions {
	
	@XmlElement(name = "PromotionData")
	private PercentOffPromotionData percentOffPromotionData;

	public void setPercentOffPromotionData(PercentOffPromotionData percentOffPromotionData) {
		this.percentOffPromotionData = percentOffPromotionData;
	}

}
