package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.TargetingCondition;

@XmlRootElement
public class PercentOffElements {

	@XmlElement(name = "TargetingCondition")
	private TargetingCondition targetingCondition;
	
	@XmlElement(name = "PurchaseCondition")
	private PercentOffPurchaseCondition percentOffPurchaseCondition;

	public void setTargetingCondition(TargetingCondition targetingCondition) {
		this.targetingCondition = targetingCondition;
	}

	public void setPercentOffPurchaseCondition(PercentOffPurchaseCondition percentOffPurchaseCondition) {
		this.percentOffPurchaseCondition = percentOffPurchaseCondition;
	}

}
