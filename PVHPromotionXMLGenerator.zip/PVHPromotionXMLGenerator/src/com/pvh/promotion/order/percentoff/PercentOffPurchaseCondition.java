package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.AnyShipMode;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifier;
import com.pvh.promotion.order.common.OrderLevelPurchaseConditionData;

@XmlRootElement
public class PercentOffPurchaseCondition {

	@XmlElement(name = "SubType")
	private String subtype;
	
	@XmlElement(name = "Sequence")
	private double sequence;
	
	@XmlElement(name = "Data")
	private OrderLevelPurchaseConditionData orderLevelPurchaseConditionData;
	
	@XmlElement(name = "IncludePaymentTypeIdentifier")
	private IncludePaymentTypeIdentifier includePaymentTypeIdentifier;

	@XmlElement(name = "AnyShipMode")
	private AnyShipMode anyShipMode;
	
	@XmlElement(name = "DiscountRange")
	private PercentOffDiscountRange percentOffDiscountRange;

	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}

	public void setOrderLevelPurchaseConditionData(OrderLevelPurchaseConditionData orderLevelPurchaseConditionData) {
		this.orderLevelPurchaseConditionData = orderLevelPurchaseConditionData;
	}

	public void setIncludePaymentTypeIdentifier(IncludePaymentTypeIdentifier includePaymentTypeIdentifier) {
		this.includePaymentTypeIdentifier = includePaymentTypeIdentifier;
	}

	public void setAnyShipMode(AnyShipMode anyShipMode) {
		this.anyShipMode = anyShipMode;
	}

	public void setPercentOffDiscountRange(PercentOffDiscountRange percentOffDiscountRange) {
		this.percentOffDiscountRange = percentOffDiscountRange;
	}


}
