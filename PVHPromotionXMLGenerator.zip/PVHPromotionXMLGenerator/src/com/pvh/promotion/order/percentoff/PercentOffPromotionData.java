package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import com.pvh.promotion.order.common.PromotionBase;
import com.pvh.promotion.order.common.PromotionDescriptions;

@XmlRootElement(name="PromotionData")
public class PercentOffPromotionData {

	@XmlElement(name = "Base")
	private PromotionBase promotionBase;
	
	@XmlElement(name = "Descriptions")
	private PromotionDescriptions promotionDescriptions;
	
	@XmlElement(name = "Elements")
	private PercentOffElements percentOffElements;

	public void setPromotionBase(PromotionBase promotionBase) {
		this.promotionBase = promotionBase;
	}

	public void setPromotionDescriptions(PromotionDescriptions promotionDescriptions) {
		this.promotionDescriptions = promotionDescriptions;
	}

	public void setPercentOffElements(PercentOffElements percentOffElements) {
		this.percentOffElements = percentOffElements;
	}

}
