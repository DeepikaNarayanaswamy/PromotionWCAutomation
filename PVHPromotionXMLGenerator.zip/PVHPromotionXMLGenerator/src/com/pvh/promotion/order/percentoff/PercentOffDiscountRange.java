package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PercentOffDiscountRange {

	@XmlElement(name = "SubType")
	private String subType;
	
	@XmlElement(name = "Sequence")
	private double sequence;
	
	@XmlElement(name = "Data")
	private PercentOffDiscountRangeData percentOffDiscountRangeData ;

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setSequence(double sequence) {
		this.sequence = sequence;
	}

	public void setPercentOffDiscountRangeData(PercentOffDiscountRangeData percentOffDiscountRangeData) {
		this.percentOffDiscountRangeData = percentOffDiscountRangeData;
	}

}
