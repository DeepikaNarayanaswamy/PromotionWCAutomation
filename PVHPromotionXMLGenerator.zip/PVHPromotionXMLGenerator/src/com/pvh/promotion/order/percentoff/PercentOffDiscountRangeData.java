package com.pvh.promotion.order.percentoff;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PercentOffDiscountRangeData {

	@XmlElement(name = "Percentage")
	private String percentage;
	
	@XmlElement(name = "LowerBound")
	private String lowerBound;

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public void setLowerBound(String lowerBound) {
		this.lowerBound = lowerBound;
	}
}
