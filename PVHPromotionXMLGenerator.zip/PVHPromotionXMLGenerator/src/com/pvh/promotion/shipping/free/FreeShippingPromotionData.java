package com.pvh.promotion.shipping.free;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.PromotionBase;
import com.pvh.promotion.order.common.PromotionDescriptions;

@XmlRootElement(name="PromotionData")
public class FreeShippingPromotionData {

	@XmlElement(name = "Base")
	private PromotionBase promotionBase;
	
	@XmlElement(name = "Descriptions")
	private PromotionDescriptions promotionDescriptions;
	
	@XmlElement(name = "Elements")
	private FreeShippingElements freeShippingElements;

	public void setPromotionBase(PromotionBase promotionBase) {
		this.promotionBase = promotionBase;
	}

	public void setPromotionDescriptions(PromotionDescriptions promotionDescriptions) {
		this.promotionDescriptions = promotionDescriptions;
	}

	public void setFreeShippingElements(FreeShippingElements freeShippingElements) {
		this.freeShippingElements = freeShippingElements;
	}
	
}
