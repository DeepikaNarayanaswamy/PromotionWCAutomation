package com.pvh.promotion.shipping.free;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.pvh.promotion.order.common.TargetingCondition;

@XmlRootElement
public class FreeShippingElements {

	@XmlElement(name = "TargetingCondition")
	private TargetingCondition targetingCondition;
	
	@XmlElement(name = "PurchaseCondition")
	private FreeShippingPurchaseCondition freeShippingPurchaseCondition;

	public void setTargetingCondition(TargetingCondition targetingCondition) {
		this.targetingCondition = targetingCondition;
	}

	public void setFreeShippingPurchaseCondition(FreeShippingPurchaseCondition freeShippingPurchaseCondition) {
		this.freeShippingPurchaseCondition = freeShippingPurchaseCondition;
	}


}
