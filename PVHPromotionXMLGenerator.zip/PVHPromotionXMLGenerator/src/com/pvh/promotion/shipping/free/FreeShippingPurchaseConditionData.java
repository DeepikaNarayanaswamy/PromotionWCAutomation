package com.pvh.promotion.shipping.free;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FreeShippingPurchaseConditionData {

	@XmlElement(name = "FixedCost")
	private String fixedCost;
	
	@XmlElement(name = "AdjustmentType")
	private String adjustmentType;
	
	@XmlElement(name = "Language")
	private String language;
	
	@XmlElement(name = "Currency")
	private String currency;
	
	@XmlElement(name = "MinimumPurchase")
	private String minimumPurchase;

	public void setFixedCost(String fixedCost) {
		this.fixedCost = fixedCost;
	}

	public void setAdjustmentType(String adjustmentType) {
		this.adjustmentType = adjustmentType;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public void setMinimumPurchase(String minimumPurchase) {
		this.minimumPurchase = minimumPurchase;
	}

}
