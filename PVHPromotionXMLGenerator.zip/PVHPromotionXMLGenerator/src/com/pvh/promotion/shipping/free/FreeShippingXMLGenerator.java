package com.pvh.promotion.shipping.free;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.pvh.promotion.order.common.AnyShipMode;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifier;
import com.pvh.promotion.order.common.IncludePaymentTypeIdentifierData;
import com.pvh.promotion.order.common.PromotionBase;
import com.pvh.promotion.order.common.PromotionDescription;
import com.pvh.promotion.order.common.PromotionDescriptions;
import com.pvh.promotion.order.common.TargetingCondition;

public class FreeShippingXMLGenerator {

	public static void main(String[] args) {
		
	try
        {
			String suffix = Integer.toString((int) Math.floor(Math.random()*100));
			
			FreeShippingPromotions freeShippingPromotions = new FreeShippingPromotions();
			
			FreeShippingPromotionData promotionData = new FreeShippingPromotionData();

			PromotionBase base = new PromotionBase();
			base.setAdministrativeName(("Free_Shipping_").concat(suffix));
			base.setAllowTransfer(0);
			base.setApplicationLimit(-1);
			base.setComments("Free shipping comments");
			base.setControlParameter("CMC");
			base.setDailyEndTime("2000-01-01 23:59:59.999");
			base.setDailyStartTime("2000-01-01 00:00:00.001");
			base.setDisplayLevel(1);
			base.setEffectiveDays(0);
			base.setEndDate("9999-12-31 23:59:59.999");
			base.setExclusive(4);
			base.setExpirationDays(0);
			base.setFriday(1);
			base.setLastUpdateByLogonId("wcsadmin");
			base.setMonday(1);
			base.setPerOrderLimit(-1);
			base.setPerShopperLimit(-1);
			base.setPriority(100);
			base.setPromotionCodeRequired(0);
			base.setPromotionGroupIdentifier("ShippingPromotion");
			base.setPromotionTypeName("OrderLevelFixedShippingDiscount");
			base.setSaturday(1);
			base.setStartDate(new Timestamp(new Date().getTime()).toString());
			base.setSunday(1);
			base.setTargetSales(0.00000);
			base.setThursday(1);
			base.setTuesday(1);
			base.setType(0);
			base.setWednesday(1);
			
			promotionData.setPromotionBase(base);
			
			PromotionDescription description = new PromotionDescription();
			description.setLanguageId(-1);
			description.setLongDescription("Long free shipping");
			description.setShortDescription("Short free shipping");
			
			PromotionDescriptions descriptions = new  PromotionDescriptions();
			descriptions.setPromotionDescription(description);

			promotionData.setPromotionDescriptions(descriptions);
			
			FreeShippingElements elements = new FreeShippingElements();
			
			TargetingCondition targetingCondition = new TargetingCondition();
			
			targetingCondition.setSequence(0.0);
			targetingCondition.setSubType("TargetingCondition");
			
			elements.setTargetingCondition(targetingCondition);
			
			FreeShippingPurchaseCondition purchaseCondition = new FreeShippingPurchaseCondition();
			
			AnyShipMode anyShipMode = new AnyShipMode();
			anyShipMode.setSequence(0.0);
			anyShipMode.setSubType("Identifier_ShipMode");
			
			purchaseCondition.setAnyShipMode(anyShipMode);
			
			FreeShippingPurchaseConditionData freeShippingPurchaseConditionData = new FreeShippingPurchaseConditionData();
			freeShippingPurchaseConditionData.setAdjustmentType("wholeOrder");
			freeShippingPurchaseConditionData.setCurrency("USD");
			freeShippingPurchaseConditionData.setLanguage("-1");
			freeShippingPurchaseConditionData.setMinimumPurchase("1");
			freeShippingPurchaseConditionData.setFixedCost("0");
			
			purchaseCondition.setFreeShippingPurchaseConditionData(freeShippingPurchaseConditionData);
			
			IncludePaymentTypeIdentifier includePaymentTypeIdentifier = new IncludePaymentTypeIdentifier();
			
			IncludePaymentTypeIdentifierData includePaymentTypeIdentifierData = new IncludePaymentTypeIdentifierData();
			includePaymentTypeIdentifierData.setPaymentType("Any");
			
			includePaymentTypeIdentifier.setIncludePaymentTypeIdentifierData(includePaymentTypeIdentifierData);
			includePaymentTypeIdentifier.setSequence(0.0);
			includePaymentTypeIdentifier.setSubType("Identifier_PaymentType");
			
			purchaseCondition.setIncludePaymentTypeIdentifier(includePaymentTypeIdentifier);
		
			purchaseCondition.setSequence(0.0);
			purchaseCondition.setSubtype("OrderLevelFixedShippingDiscountPurchaseCondition");
			
			elements.setFreeShippingPurchaseCondition(purchaseCondition);

			promotionData.setFreeShippingElements(elements);
			
			freeShippingPromotions.setFreeShippingPromotionData(promotionData);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(FreeShippingPromotions.class);
             
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
 
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
 
            StringWriter stringWriter = new StringWriter();
             
            jaxbMarshaller.marshal(freeShippingPromotions, stringWriter);
             
            String xmlContent = stringWriter.toString();
            System.out.println( xmlContent );
 
            try {
            	String path = "C:/IBM/WCDE80/samples/DataLoad/Promotion/FreeShipping.xml";
                File newTextFile = new File(path);

                FileWriter fw = new FileWriter(newTextFile);
                fw.write(xmlContent);
                fw.close();

            } catch (IOException iox) {
                iox.printStackTrace();
            }
            
        } catch (JAXBException e) {
            e.printStackTrace();
        }
	}
}
