package com.pvh.promotion.shipping.free;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Promotions")
public class FreeShippingPromotions {
	
	@XmlElement(name="PromotionData")
	private FreeShippingPromotionData freeShippingPromotionData;

	public void setFreeShippingPromotionData(FreeShippingPromotionData freeShippingPromotionData) {
		this.freeShippingPromotionData = freeShippingPromotionData;
	}
}
